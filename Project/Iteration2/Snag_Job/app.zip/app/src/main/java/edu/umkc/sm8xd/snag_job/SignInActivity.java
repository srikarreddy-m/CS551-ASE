package edu.umkc.sm8xd.snag_job;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebView;

/**
 * Created by SrikarReddy on 2/21/2015.
 */
public class SignInActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signin_first);
        final WebView websiteview1 = (WebView)(findViewById(R.id.webView1));
        websiteview1.loadUrl("file:///android_asset/bootstraptheme1/index.html");
    }
}
