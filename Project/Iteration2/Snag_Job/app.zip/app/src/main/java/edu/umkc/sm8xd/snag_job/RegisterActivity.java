package edu.umkc.sm8xd.snag_job;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.widget.Button;
/**
 * Created by SrikarReddy on 2/19/2015.
 */
public  class RegisterActivity extends Activity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.registerpage);

    }
}
